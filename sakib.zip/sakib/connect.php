<?php 
 $name=$_POST['name']; 
 $email=$_POST['email']; 
 $mobile=$_POST['mobile']; 
 $date=$_POST['date']; 
 $time=$_POST['time']; 
  

  
 $conn = new mysqli('localhost','root','','burgerking');

if ($conn->connect_error) 
{ 
     die('Connection Failed : ' .$conn->connect_error);

} 
else  
{ 
    $stmt = $conn->prepare("insert into boook(name,email,mobile,date,time) 
    values(?,?,?,?,?)"); 
     
    $stmt->bind_param("ssiss",$name, $email, $mobile, $date, $time); 
    $stmt->execute();    

    $stmt->close();  

    $conn->close();
}

?>